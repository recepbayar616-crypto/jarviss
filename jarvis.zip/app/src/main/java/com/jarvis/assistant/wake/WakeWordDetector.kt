package com.jarvis.assistant.wake

/**
 * Wake-word mimarisi. Android'de SpeechRecognizer sürekli arka plan dinlemesi için
 * tasarlanmamıştır (oturumlar kapanır, bip sesi çıkar, pil harcar, arka planda çalışmaz).
 * Gerçek "Hey Jarvis" için Phase 6'da cihaz-içi bir wake-word motoru (foreground service)
 * ve/veya varsayılan asistan entegrasyonu bu arayüzün arkasına eklenecek.
 */
interface WakeWordDetector {
    val isSupported: Boolean
    val description: String

    /** Başlatılabildiyse true. Algılanınca [onWake] çağrılır. */
    fun start(onWake: () -> Unit): Boolean
    fun stop()
}

class UnavailableWakeWordDetector : WakeWordDetector {
    override val isSupported = false
    override val description =
        "Arka planda sürekli \"Hey Jarvis\" dinleme henüz aktif değil (Phase 6). " +
            "Şimdilik mikrofon düğmesine dokunup \"Jarvis, ...\" diyebilirsiniz."

    override fun start(onWake: () -> Unit): Boolean = false
    override fun stop() {}
}
