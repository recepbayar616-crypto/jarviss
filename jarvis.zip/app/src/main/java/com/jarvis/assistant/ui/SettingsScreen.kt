package com.jarvis.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.assistant.core.JarvisColors

@Composable
fun SettingsScreen(
    s: SettingsUiState,
    onBack: () -> Unit,
    onSaveKey: (String) -> Unit,
    onClearKey: () -> Unit,
    onSaveModel: (String) -> Unit,
    onTest: () -> Unit,
) {
    // Anahtar rememberSaveable ile TUTULMAZ (kaydedilmiş durum paketine yazılmasın).
    var keyInput by remember { mutableStateOf("") }
    var modelInput by remember(s.model) { mutableStateOf(s.model) }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White,
        cursorColor = JarvisColors.Cyan,
        focusedBorderColor = JarvisColors.Cyan,
        unfocusedBorderColor = JarvisColors.DarkCyan,
        focusedLabelColor = JarvisColors.Cyan,
        unfocusedLabelColor = JarvisColors.LightCyan,
    )
    val buttonColors = ButtonDefaults.buttonColors(
        containerColor = JarvisColors.Cyan.copy(alpha = 0.22f),
        contentColor = JarvisColors.Cyan,
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisColors.Background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row {
            TextButton(onClick = onBack) {
                Text("← GERİ", color = JarvisColors.Cyan, fontSize = 13.sp)
            }
        }
        Text(
            "AYARLAR",
            color = JarvisColors.Cyan,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
        )

        Text("GEMINI API ANAHTARI", color = JarvisColors.LightCyan, fontSize = 12.sp, letterSpacing = 1.sp)
        Text(
            text = if (s.hasKey) "Durum: kayıtlı (şifreli)" else "Durum: girilmemiş",
            color = if (s.hasKey) JarvisColors.Cyan else JarvisColors.Error,
            fontSize = 14.sp,
        )
        if (!s.secureAvailable) {
            Text(
                "Uyarı: Bu cihazda şifreli depolama kullanılamıyor, anahtar kaydedilemez.",
                color = JarvisColors.Error,
                fontSize = 13.sp,
            )
        }
        OutlinedTextField(
            value = keyInput,
            onValueChange = { keyInput = it },
            label = { Text("API anahtarını yapıştırın") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            colors = fieldColors,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    onSaveKey(keyInput)
                    keyInput = ""
                },
                colors = buttonColors,
            ) { Text("Kaydet") }
            Button(onClick = onClearKey, colors = buttonColors) { Text("Anahtarı sil") }
        }
        Text(
            "Anahtarı aistudio.google.com adresinden (Get API key) ücretsiz alabilirsiniz.",
            color = Color.White.copy(alpha = 0.6f),
            fontSize = 12.sp,
        )

        Text("MODEL", color = JarvisColors.LightCyan, fontSize = 12.sp, letterSpacing = 1.sp)
        OutlinedTextField(
            value = modelInput,
            onValueChange = { modelInput = it },
            label = { Text("Gemini model adı") },
            singleLine = true,
            colors = fieldColors,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onSaveModel(modelInput) }, colors = buttonColors) { Text("Modeli kaydet") }
            Button(onClick = onTest, enabled = !s.testing, colors = buttonColors) {
                Text(if (s.testing) "Test ediliyor…" else "Bağlantıyı test et")
            }
        }
        Text(
            "Model hata verirse (404/izin) başka bir Gemini model adı deneyin.",
            color = Color.White.copy(alpha = 0.6f),
            fontSize = 12.sp,
        )

        s.message?.let {
            Text(
                it,
                color = if (s.messageIsError) JarvisColors.Error else JarvisColors.Cyan,
                fontSize = 14.sp,
            )
        }

        Text("WAKE WORD", color = JarvisColors.LightCyan, fontSize = 12.sp, letterSpacing = 1.sp)
        Text(s.wakeInfo, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
    }
}
