package com.jarvis.assistant.settings

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.jarvis.assistant.ai.GeminiProvider

/**
 * API anahtarı Android Keystore ile şifrelenmiş SharedPreferences'ta tutulur.
 * Şifreli depolama kullanılamazsa anahtar düz metin olarak KAYDEDİLMEZ.
 */
class SettingsStore(context: Context) {

    private val appContext = context.applicationContext
    private val plain: SharedPreferences =
        appContext.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

    private val secure: SharedPreferences? by lazy {
        try {
            val masterKey = MasterKey.Builder(appContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                appContext,
                "jarvis_secure",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
            )
        } catch (e: Exception) {
            null
        }
    }

    val secureStorageAvailable: Boolean get() = secure != null

    fun getApiKey(): String? =
        secure?.getString(KEY_API, null)?.takeIf { it.isNotBlank() }

    fun saveApiKey(key: String): Boolean {
        val s = secure ?: return false
        s.edit().putString(KEY_API, key.trim()).apply()
        return true
    }

    fun clearApiKey() {
        secure?.edit()?.remove(KEY_API)?.apply()
    }

    var model: String
        get() = plain.getString(KEY_MODEL, null)?.takeIf { it.isNotBlank() }
            ?: GeminiProvider.DEFAULT_MODEL
        set(value) {
            plain.edit().putString(KEY_MODEL, value.trim()).apply()
        }

    /** "tr" veya "en" */
    var language: String
        get() = plain.getString(KEY_LANG, "tr") ?: "tr"
        set(value) {
            plain.edit().putString(KEY_LANG, value).apply()
        }

    private companion object {
        const val KEY_API = "gemini_api_key"
        const val KEY_MODEL = "gemini_model"
        const val KEY_LANG = "language"
    }
}
