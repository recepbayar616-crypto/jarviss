package com.jarvis.assistant.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/**
 * Gemini REST (generateContent). API anahtarı URL'ye değil x-goog-api-key başlığına konur
 * ve hiçbir yere loglanmaz.
 */
class GeminiProvider(
    private val apiKey: () -> String?,
    private val model: () -> String,
) : AIProvider {

    override val id = "gemini"

    private sealed interface Raw {
        data class Http(val code: Int, val body: String) : Raw
        data class Fail(val message: String) : Raw
    }

    override suspend fun generate(systemPrompt: String, history: List<ChatMessage>): AiResult =
        withContext(Dispatchers.IO) {
            val key = apiKey()?.trim().orEmpty()
            if (key.isEmpty()) {
                return@withContext AiResult.Failure("Gemini API anahtarı girilmemiş. Ayarlar'dan ekleyin.")
            }
            val modelName = sanitizeModel(model())

            // Hızlı sesli cevap için düşük düşünme seviyesi. Model desteklemiyorsa (HTTP 400) onsuz tekrar dene.
            val first = call(key, modelName, buildBody(systemPrompt, history, thinkingLow = true))
            val raw = if (first is Raw.Http && first.code == 400 &&
                first.body.contains("thinking", ignoreCase = true)
            ) {
                call(key, modelName, buildBody(systemPrompt, history, thinkingLow = false))
            } else {
                first
            }

            when (raw) {
                is Raw.Fail -> AiResult.Failure(raw.message)
                is Raw.Http ->
                    if (raw.code in 200..299) parseSuccess(raw.body)
                    else AiResult.Failure(describeHttpError(raw.code, raw.body))
            }
        }

    private fun buildBody(systemPrompt: String, history: List<ChatMessage>, thinkingLow: Boolean): String {
        val contents = JSONArray()
        for (m in history) {
            contents.put(
                JSONObject()
                    .put("role", if (m.role == Role.USER) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", m.text)))
            )
        }
        val root = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            )
            .put("contents", contents)
        if (thinkingLow) {
            root.put(
                "generationConfig",
                JSONObject().put("thinkingConfig", JSONObject().put("thinkingLevel", "low"))
            )
        }
        return root.toString()
    }

    private fun call(key: String, modelName: String, body: String): Raw {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent")
            val c = url.openConnection() as HttpURLConnection
            conn = c
            c.requestMethod = "POST"
            c.connectTimeout = 15_000
            c.readTimeout = 45_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            Raw.Http(code, text)
        } catch (e: UnknownHostException) {
            Raw.Fail("İnternet bağlantısı yok veya Gemini sunucusuna ulaşılamıyor.")
        } catch (e: SocketTimeoutException) {
            Raw.Fail("Gemini zamanında yanıt vermedi. Tekrar deneyin.")
        } catch (e: IOException) {
            Raw.Fail("Gemini bağlantı hatası (${e.javaClass.simpleName}).")
        } finally {
            conn?.disconnect()
        }
    }

    private fun parseSuccess(text: String): AiResult {
        return try {
            val root = JSONObject(text)
            val candidates = root.optJSONArray("candidates")
            val first = candidates?.optJSONObject(0)
            val parts = first?.optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.optJSONObject(i) ?: continue
                    if (!part.optBoolean("thought", false)) sb.append(part.optString("text", ""))
                }
            }
            val out = sb.toString().trim()
            if (out.isNotEmpty()) {
                AiResult.Success(out)
            } else {
                val block = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
                val finish = first?.optString("finishReason").orEmpty()
                AiResult.Failure(
                    when {
                        block.isNotEmpty() -> "Gemini bu isteği güvenlik filtresi nedeniyle yanıtlamadı ($block)."
                        finish.isNotEmpty() -> "Gemini boş yanıt döndürdü ($finish)."
                        else -> "Gemini boş yanıt döndürdü."
                    }
                )
            }
        } catch (e: JSONException) {
            AiResult.Failure("Gemini yanıtı okunamadı.")
        }
    }

    private fun describeHttpError(code: Int, body: String): String {
        val apiMsg = try {
            JSONObject(body).optJSONObject("error")?.optString("message").orEmpty()
        } catch (e: JSONException) {
            ""
        }
        return when {
            code == 400 && apiMsg.contains("API key", ignoreCase = true) ->
                "Gemini API anahtarı geçersiz. Ayarlar'dan anahtarı kontrol edin."
            code == 400 -> "Gemini isteği reddetti (HTTP 400): ${apiMsg.take(160)}"
            code == 401 || code == 403 ->
                "Gemini anahtarı reddedildi veya bu modele erişim izniniz yok (HTTP $code)."
            code == 404 ->
                "Model bulunamadı veya hesabınız bu modele erişemiyor. Ayarlar'dan model adını değiştirin."
            code == 429 -> "Gemini kullanım sınırına ulaşıldı (HTTP 429). Biraz sonra tekrar deneyin."
            code >= 500 -> "Gemini servisi şu anda yanıt vermiyor (HTTP $code)."
            else -> "Gemini hatası (HTTP $code): ${apiMsg.take(160)}"
        }
    }

    private fun sanitizeModel(raw: String): String =
        raw.trim().removePrefix("models/")
            .filter { it.isLetterOrDigit() || it == '.' || it == '_' || it == '-' }
            .ifEmpty { DEFAULT_MODEL }

    companion object {
        const val DEFAULT_MODEL = "gemini-3.5-flash-lite"
    }
}
