package com.jarvis.assistant.core

/** Anahtarlar string olduğu için yeni bir tool kendi context'ini kolayca ekleyebilir. */
object ContextKeys {
    const val GENERAL = "general"
    const val YOUTUBE = "youtube"
    const val SPOTIFY = "spotify"
    const val WHATSAPP = "whatsapp"
    const val GMAIL = "gmail"
    const val INSTAGRAM = "instagram"
    const val GOOGLE = "google"
    const val CHROME = "chrome"
    const val MAPS = "maps"
    const val CALENDAR = "calendar"
    const val ANDROID = "android"
    const val WEATHER = "weather"
    const val SYSTEM = "system"
    const val NETWORK = "network"
    const val BATTERY = "battery"
    const val MEMORY = "memory"
    const val CAMERA = "camera"
    const val SCREEN = "screen"
    const val NOTIFICATIONS = "notifications"
}

/** HUD header için: "TITLE / ● STATUS" ve renk anahtarı. */
data class ContextInfo(
    val key: String,
    val title: String,
    val status: String,
) {
    companion object {
        val GENERAL = ContextInfo(ContextKeys.GENERAL, "J.A.R.V.I.S.", "READY")
    }
}
