package com.jarvis.assistant.ui

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.ai.AIProvider
import com.jarvis.assistant.ai.AiResult
import com.jarvis.assistant.ai.ChatMessage
import com.jarvis.assistant.ai.GeminiProvider
import com.jarvis.assistant.ai.JarvisPrompt
import com.jarvis.assistant.ai.Role
import com.jarvis.assistant.ai.WakePhrase
import com.jarvis.assistant.core.ContextInfo
import com.jarvis.assistant.core.ContextKeys
import com.jarvis.assistant.core.HudPhase
import com.jarvis.assistant.core.HudUiState
import com.jarvis.assistant.settings.SettingsStore
import com.jarvis.assistant.tool.SystemStatusTool
import com.jarvis.assistant.tool.ToolRegistry
import com.jarvis.assistant.tool.ToolResult
import com.jarvis.assistant.voice.AndroidTtsProvider
import com.jarvis.assistant.voice.SpeechInput
import com.jarvis.assistant.voice.SpeechInputListener
import com.jarvis.assistant.voice.SpeechListener
import com.jarvis.assistant.voice.VoiceProvider
import com.jarvis.assistant.wake.UnavailableWakeWordDetector
import com.jarvis.assistant.wake.WakeWordDetector
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SettingsUiState(
    val hasKey: Boolean,
    val model: String,
    val language: String,
    val secureAvailable: Boolean,
    val wakeInfo: String,
    val message: String? = null,
    val messageIsError: Boolean = false,
    val testing: Boolean = false,
)

class JarvisViewModel(app: Application) : AndroidViewModel(app) {

    private val settings = SettingsStore(app)
    private val registry = ToolRegistry(app).apply { register(SystemStatusTool(app)) }
    private val voice: VoiceProvider = AndroidTtsProvider(app)
    private val speechInput = SpeechInput(app)
    private val ai: AIProvider = GeminiProvider({ settings.getApiKey() }, { settings.model })
    private val wakeDetector: WakeWordDetector = UnavailableWakeWordDetector()

    private val history = mutableListOf<ChatMessage>()
    private var askJob: Job? = null

    private val _state = MutableStateFlow(HudUiState())
    val state: StateFlow<HudUiState> = _state.asStateFlow()

    private val _settingsState = MutableStateFlow(readSettings())
    val settingsState: StateFlow<SettingsUiState> = _settingsState.asStateFlow()

    // ---------------------------------------------------------------- helpers

    private fun readSettings() = SettingsUiState(
        hasKey = settings.getApiKey() != null,
        model = settings.model,
        language = settings.language,
        secureAvailable = settings.secureStorageAvailable,
        wakeInfo = wakeDetector.description,
    )

    private fun generalContext(status: String) = ContextInfo(ContextKeys.GENERAL, "J.A.R.V.I.S.", status)

    private fun recognitionTag() = if (settings.language == "en") "en-US" else "tr-TR"

    private fun greetingText() =
        if (settings.language == "en") "Hello sir, how may I help you?"
        else "Merhaba efendim, nasıl yardımcı olabilirim?"

    private fun hasMicPermission() =
        ContextCompat.checkSelfPermission(getApplication(), Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun idle(notice: String? = null) {
        _state.update {
            it.copy(
                phase = HudPhase.IDLE,
                context = generalContext("READY"),
                amplitude = 0f,
                notice = notice,
            )
        }
    }

    private fun fail(message: String, micBlocked: Boolean = false) {
        _state.update {
            it.copy(
                phase = HudPhase.ERROR,
                context = generalContext("ERROR"),
                amplitude = 0f,
                error = message,
                notice = null,
                micBlocked = micBlocked,
            )
        }
    }

    /** Devam eden dinleme / düşünme / konuşmayı durdurur. */
    private fun stopEverything() {
        askJob?.cancel()
        askJob = null
        speechInput.cancel()
        voice.stop()
        if (history.lastOrNull()?.role == Role.USER) history.removeAt(history.lastIndex)
    }

    private fun trimHistory() {
        while (history.size > MAX_HISTORY) history.removeAt(0)
        while (history.isNotEmpty() && history.first().role != Role.USER) history.removeAt(0)
    }

    // ---------------------------------------------------------------- mic flow

    fun onMicClicked() {
        when (_state.value.phase) {
            HudPhase.LISTENING -> speechInput.stopListening()
            HudPhase.THINKING, HudPhase.EXECUTING -> {
                stopEverything()
                idle()
            }
            HudPhase.SPEAKING -> startListening()
            else -> startListening()
        }
    }

    fun onMicPermissionDenied(permanentlyBlocked: Boolean) {
        fail(
            "Mikrofon izni verilmedi. Sesli komut için izin gerekli.",
            micBlocked = permanentlyBlocked,
        )
    }

    fun startListening() {
        if (!hasMicPermission()) {
            fail("Mikrofon izni verilmedi. Sesli komut için izin gerekli.", micBlocked = true)
            return
        }
        if (settings.getApiKey().isNullOrBlank()) {
            fail("Gemini API anahtarı girilmemiş. Sağ üstteki AYARLAR'dan anahtarınızı ekleyin.")
            return
        }
        if (!speechInput.isAvailable()) {
            fail("Bu cihazda konuşma tanıma servisi bulunamadı. Google uygulamasının yüklü ve güncel olduğundan emin olun.")
            return
        }
        stopEverything()
        _state.update {
            it.copy(
                phase = HudPhase.LISTENING,
                context = generalContext("LISTENING"),
                amplitude = 0f,
                userText = "",
                lastSpeech = "",
                spokenEnd = 0,
                error = null,
                notice = null,
                micBlocked = false,
            )
        }
        speechInput.start(recognitionTag(), object : SpeechInputListener {
            override fun onPartial(text: String) {
                _state.update { it.copy(userText = text) }
            }

            override fun onLevel(level: Float) {
                _state.update { if (it.phase == HudPhase.LISTENING) it.copy(amplitude = level) else it }
            }

            override fun onEndOfSpeech() {
                _state.update {
                    if (it.phase == HudPhase.LISTENING) {
                        it.copy(phase = HudPhase.THINKING, context = generalContext("PROCESSING"), amplitude = 0f)
                    } else it
                }
            }

            override fun onFinal(text: String) {
                handleUtterance(text)
            }

            override fun onError(message: String, isNoSpeech: Boolean) {
                if (isNoSpeech) idle(notice = message) else fail(message)
            }
        })
    }

    private fun handleUtterance(raw: String) {
        val wake = WakePhrase.strip(raw)
        if (wake.command.isBlank()) {
            // Yalnızca "Jarvis" / "Hey Jarvis" denildi.
            _state.update { it.copy(userText = raw) }
            speakReply(greetingText(), generalContext("SPEAKING")) { startListening() }
            return
        }
        ask(wake.command)
    }

    // ---------------------------------------------------------------- Gemini

    private fun ask(command: String) {
        askJob?.cancel()
        _state.update {
            it.copy(
                phase = HudPhase.THINKING,
                context = generalContext("PROCESSING"),
                amplitude = 0f,
                userText = command,
                lastSpeech = "",
                spokenEnd = 0,
                error = null,
                notice = null,
            )
        }
        history.add(ChatMessage(Role.USER, command))
        askJob = viewModelScope.launch {
            when (val result = ai.generate(JarvisPrompt.systemPrompt(), history.toList())) {
                is AiResult.Success -> {
                    val reply = JarvisPrompt.cleanForSpeech(result.text)
                    if (reply.isEmpty()) {
                        if (history.lastOrNull()?.role == Role.USER) history.removeAt(history.lastIndex)
                        fail("Gemini boş yanıt döndürdü.")
                    } else {
                        history.add(ChatMessage(Role.MODEL, reply))
                        trimHistory()
                        speakReply(reply, generalContext("SPEAKING"))
                    }
                }
                is AiResult.Failure -> {
                    if (history.lastOrNull()?.role == Role.USER) history.removeAt(history.lastIndex)
                    fail(result.message)
                }
            }
        }
    }

    // ---------------------------------------------------------------- Phase 2 features (korundu)

    fun greet() {
        stopEverything()
        speakReply(greetingText(), generalContext("SPEAKING"))
    }

    fun showSystemStatus() {
        stopEverything()
        viewModelScope.launch {
            val ctx = registry.get(SystemStatusTool.NAME)?.contextInfo ?: ContextInfo.GENERAL
            _state.update {
                it.copy(
                    phase = HudPhase.EXECUTING,
                    context = ctx,
                    userText = "",
                    error = null,
                    notice = null,
                    micBlocked = false,
                )
            }
            when (val result = registry.execute(SystemStatusTool.NAME)) {
                is ToolResult.Success -> speakReply(result.summary, ctx)
                is ToolResult.Failure -> {
                    _state.update { it.copy(phase = HudPhase.ERROR, error = result.message) }
                    speakReply(result.message, ctx)
                }
            }
        }
    }

    // ---------------------------------------------------------------- speaking

    private fun speakReply(text: String, ctx: ContextInfo, onFinished: (() -> Unit)? = null) {
        _state.update {
            it.copy(
                context = ctx,
                lastSpeech = text,
                spokenEnd = 0,
                phase = HudPhase.SPEAKING,
                amplitude = 0f,
            )
        }
        voice.speak(
            text,
            object : SpeechListener {
                override fun onWordRange(start: Int, end: Int) {
                    _state.update { it.copy(spokenEnd = end) }
                }

                override fun onDone() {
                    var finished = false
                    _state.update {
                        if (it.phase == HudPhase.SPEAKING) {
                            finished = true
                            it.copy(
                                phase = HudPhase.IDLE,
                                spokenEnd = it.lastSpeech.length,
                                context = if (ctx.key == ContextKeys.GENERAL) generalContext("READY") else ctx,
                            )
                        } else it
                    }
                    if (finished) onFinished?.let { next -> viewModelScope.launch { next() } }
                }

                override fun onError(message: String) {
                    fail("Ses çıkışı hatası: $message")
                }
            },
            JarvisPrompt.ttsLanguageTag(text, settings.language),
        )
    }

    // ---------------------------------------------------------------- wake word (Phase 6 için hazır)

    /** Bir WakeWordDetector "Jarvis" algıladığında çağrılır. */
    fun onWakeWordDetected() {
        speakReply(greetingText(), generalContext("SPEAKING")) { startListening() }
    }

    // ---------------------------------------------------------------- settings

    private fun refreshSettings(message: String? = null, isError: Boolean = false, testing: Boolean = false) {
        _settingsState.value = readSettings().copy(message = message, messageIsError = isError, testing = testing)
    }

    fun saveApiKey(key: String) {
        val trimmed = key.trim()
        if (trimmed.isEmpty()) {
            refreshSettings("Anahtar boş olamaz.", isError = true)
            return
        }
        if (settings.saveApiKey(trimmed)) {
            refreshSettings("Anahtar şifreli olarak kaydedildi.")
        } else {
            refreshSettings(
                "Bu cihazda güvenli depolama kullanılamıyor; anahtar kaydedilmedi.",
                isError = true,
            )
        }
    }

    fun clearApiKey() {
        settings.clearApiKey()
        refreshSettings("Anahtar silindi.")
    }

    fun saveModel(model: String) {
        settings.model = model
        refreshSettings("Model kaydedildi: ${settings.model}")
    }

    fun setLanguage(language: String) {
        settings.language = language
        refreshSettings()
    }

    fun testGemini() {
        if (settings.getApiKey().isNullOrBlank()) {
            refreshSettings("Önce API anahtarını kaydedin.", isError = true)
            return
        }
        refreshSettings("Gemini'ye bağlanılıyor…", testing = true)
        viewModelScope.launch {
            val result = ai.generate(
                "Çok kısa cevap ver.",
                listOf(ChatMessage(Role.USER, "Sadece \"tamam\" yaz.")),
            )
            when (result) {
                is AiResult.Success -> refreshSettings("Gemini bağlantısı çalışıyor (${settings.model}).")
                is AiResult.Failure -> refreshSettings(result.message, isError = true)
            }
        }
    }

    override fun onCleared() {
        askJob?.cancel()
        speechInput.destroy()
        voice.release()
    }

    private companion object {
        const val MAX_HISTORY = 12
    }
}
