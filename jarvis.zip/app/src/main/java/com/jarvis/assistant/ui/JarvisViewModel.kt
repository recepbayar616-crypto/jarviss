package com.jarvis.assistant.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.core.ContextInfo
import com.jarvis.assistant.core.HudPhase
import com.jarvis.assistant.core.HudUiState
import com.jarvis.assistant.tool.SystemStatusTool
import com.jarvis.assistant.tool.ToolRegistry
import com.jarvis.assistant.tool.ToolResult
import com.jarvis.assistant.voice.AndroidTtsProvider
import com.jarvis.assistant.voice.SpeechListener
import com.jarvis.assistant.voice.VoiceProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class JarvisViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(HudUiState())
    val state: StateFlow<HudUiState> = _state.asStateFlow()

    private val registry = ToolRegistry(app).apply { register(SystemStatusTool(app)) }
    private val voice: VoiceProvider = AndroidTtsProvider(app)

    fun greet() {
        speak("Merhaba efendim, nasıl yardımcı olabilirim?", ContextInfo.GENERAL)
    }

    fun showSystemStatus() {
        viewModelScope.launch {
            val ctx = registry.get(SystemStatusTool.NAME)?.contextInfo ?: ContextInfo.GENERAL
            _state.update { it.copy(phase = HudPhase.EXECUTING, context = ctx, error = null) }
            when (val result = registry.execute(SystemStatusTool.NAME)) {
                is ToolResult.Success -> speak(result.summary, ctx)
                is ToolResult.Failure -> {
                    _state.update { it.copy(phase = HudPhase.ERROR, error = result.message) }
                    speak(result.message, ctx)
                }
            }
        }
    }

    private fun speak(text: String, ctx: ContextInfo) {
        _state.update {
            it.copy(context = ctx, lastSpeech = text, spokenEnd = 0, phase = HudPhase.SPEAKING)
        }
        voice.speak(text, object : SpeechListener {
            override fun onWordRange(start: Int, end: Int) {
                _state.update { it.copy(spokenEnd = end) }
            }

            override fun onDone() {
                _state.update { it.copy(phase = HudPhase.IDLE, spokenEnd = it.lastSpeech.length) }
            }

            override fun onError(message: String) {
                _state.update { it.copy(phase = HudPhase.ERROR, error = message) }
            }
        })
    }

    override fun onCleared() {
        voice.release()
    }
}
