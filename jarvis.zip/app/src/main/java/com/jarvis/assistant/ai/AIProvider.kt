package com.jarvis.assistant.ai

enum class Role { USER, MODEL }

data class ChatMessage(val role: Role, val text: String)

sealed interface AiResult {
    data class Success(val text: String) : AiResult
    data class Failure(val message: String) : AiResult
}

/** Beyin katmanı soyutlaması. Gemini dışında bir sağlayıcı eklemek için bunu uygula. */
interface AIProvider {
    val id: String
    suspend fun generate(systemPrompt: String, history: List<ChatMessage>): AiResult
}
