package com.jarvis.assistant.ai

import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

object JarvisPrompt {

    fun systemPrompt(): String {
        val now = ZonedDateTime.now(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("d MMMM yyyy EEEE HH:mm", Locale("tr", "TR")))
        return """
Sen J.A.R.V.I.S.'sin: bir Android telefonda çalışan kişisel sesli asistan. Cevapların sesli okunacak.
Kurallar:
- Kullanıcı hangi dilde konuşuyorsa (Türkçe veya İngilizce) o dilde cevap ver.
- Kısa ve net ol; çoğunlukla 1-3 cümle.
- Sakin, zeki ve profesyonel bir ton kullan. Türkçede gerektiğinde, her cümlede değil, ara sıra "efendim" de.
- Markdown, madde işareti, emoji, yıldız, başlık kullanma. Düz konuşma metni yaz.
- Şu an telefonda işlem yapamazsın (uygulama açma, mesaj veya e-posta gönderme/okuma, YouTube/Spotify/Gmail verileri, hava durumu gibi). Bunlar istenirse bu yeteneğin henüz eklenmediğini kısaca ve dürüstçe söyle. Gerçek zamanlı veri uydurma.
- Bilmediğin şeyi bilmediğini söyle.
Şu anki tarih ve saat (cihaz): $now
""".trimIndent()
    }

    /** Markdown kalıntılarını temizler; HUD ve TTS aynı metni kullanır. */
    fun cleanForSpeech(text: String): String =
        text.replace(Regex("[*#`_>]+"), "")
            .replace(Regex("\\s*\\n+\\s*"), ". ")
            .replace(Regex("\\s+"), " ")
            .trim()

    /** Cevabın diline göre TTS dili. Türkçeye özgü harf varsa tr-TR, yoksa seçili dil. */
    fun ttsLanguageTag(text: String, selectedLanguage: String): String {
        val turkishChars = "çğışöüÇĞİŞÖÜ"
        if (text.any { it in turkishChars && it !in "çöüÇÖÜ" }) return "tr-TR"
        return if (selectedLanguage == "en") "en-US" else "tr-TR"
    }
}

data class WakeResult(val woke: Boolean, val command: String)

/**
 * "Jarvis" / "Hey Jarvis" ön ekini komuttan ayırır. Konuşma tanıma bu kelimeyi farklı
 * yazabildiği için yaygın varyantlar da kabul edilir.
 */
object WakePhrase {
    private val prefixes = listOf(
        "hey jarvis", "hey cervis", "hey carvis", "hey jarvıs", "hey harvis",
        "jarvis", "cervis", "carvis", "jarvıs", "harvis",
    )

    fun strip(text: String): WakeResult {
        val t = text.trim()
        val lower = t.lowercase(Locale.ROOT)
        for (p in prefixes) {
            if (lower.startsWith(p)) {
                val rest = t.substring(p.length).trimStart(' ', ',', '.', '!', '?', ':', ';', '-').trim()
                return WakeResult(true, rest)
            }
        }
        return WakeResult(false, t)
    }
}
