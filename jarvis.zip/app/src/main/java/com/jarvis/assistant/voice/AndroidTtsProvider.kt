package com.jarvis.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

/**
 * Android TTS fallback. Progress: UtteranceProgressListener.onRangeStart (API 26+).
 * Not: Android TTS ham ses akışı vermez, bu yüzden amplitude üretmez.
 * Gerçek amplitude ElevenLabs (PCM çalma) fazında eklenecek.
 */
class AndroidTtsProvider(context: Context) : VoiceProvider {

    override val id = "android_tts"

    var speechRate = 1.05f
    var pitch = 1.0f

    private data class Pending(val text: String, val listener: SpeechListener, val languageTag: String)

    private var tts: TextToSpeech? = null
    private var ready = false
    private var initFailed = false
    private var pending: Pending? = null
    private var listener: SpeechListener? = null

    private val progress = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            listener?.onStart()
        }

        override fun onDone(utteranceId: String?) {
            listener?.onDone()
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            listener?.onError("TTS hatası")
        }

        override fun onError(utteranceId: String?, errorCode: Int) {
            listener?.onError("TTS hatası ($errorCode)")
        }

        override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
            listener?.onWordRange(start, end)
        }
    }

    init {
        tts = TextToSpeech(context.applicationContext) { status -> onInit(status) }
    }

    @Synchronized
    private fun onInit(status: Int) {
        val engine = tts
        if (status != TextToSpeech.SUCCESS || engine == null) {
            initFailed = true
            pending?.listener?.onError("Android TTS başlatılamadı. Telefonda bir metin okuma (TTS) motoru yüklü mü?")
            pending = null
            return
        }
        engine.setOnUtteranceProgressListener(progress)
        ready = true
        val queued = pending
        pending = null
        if (queued != null) speak(queued.text, queued.listener, queued.languageTag)
    }

    override suspend fun isAvailable(): Boolean = !initFailed

    @Synchronized
    override fun speak(text: String, listener: SpeechListener, languageTag: String) {
        this.listener = listener
        val engine = tts
        if (initFailed || engine == null) {
            listener.onError("Android TTS kullanılamıyor.")
            return
        }
        if (!ready) {
            pending = Pending(text, listener, languageTag)
            return
        }
        val result = engine.setLanguage(Locale.forLanguageTag(languageTag))
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.getDefault())
        }
        engine.setSpeechRate(speechRate)
        engine.setPitch(pitch)
        val status = engine.speak(text.take(3900), TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
        if (status == TextToSpeech.ERROR) listener.onError("Konuşma başlatılamadı.")
    }

    override fun stop() {
        tts?.stop()
    }

    @Synchronized
    override fun release() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
