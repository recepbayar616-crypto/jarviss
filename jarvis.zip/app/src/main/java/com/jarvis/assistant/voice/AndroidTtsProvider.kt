package com.jarvis.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

/**
 * Android TTS fallback. Progress: UtteranceProgressListener.onRangeStart (API 26+).
 * Not: Android TTS ham ses akışı vermez, bu yüzden amplitude üretmez.
 * Gerçek amplitude ElevenLabs (PCM çalma) fazında eklenecek.
 */
class AndroidTtsProvider(context: Context) : VoiceProvider {

    override val id = "android_tts"

    var speechRate = 1.05f
    var pitch = 1.0f

    private var tts: TextToSpeech? = null
    private var ready = false
    private var initFailed = false
    private var pending: Pair<String, SpeechListener>? = null
    private var listener: SpeechListener? = null

    private val progress = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            listener?.onStart()
        }

        override fun onDone(utteranceId: String?) {
            listener?.onDone()
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            listener?.onError("TTS hatası")
        }

        override fun onError(utteranceId: String?, errorCode: Int) {
            listener?.onError("TTS hatası ($errorCode)")
        }

        override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
            listener?.onWordRange(start, end)
        }
    }

    init {
        tts = TextToSpeech(context.applicationContext) { status -> onInit(status) }
    }

    @Synchronized
    private fun onInit(status: Int) {
        val engine = tts
        if (status != TextToSpeech.SUCCESS || engine == null) {
            initFailed = true
            pending?.second?.onError("Android TTS başlatılamadı")
            pending = null
            return
        }
        val result = engine.setLanguage(Locale("tr", "TR"))
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.getDefault())
        }
        engine.setOnUtteranceProgressListener(progress)
        ready = true
        val queued = pending
        pending = null
        if (queued != null) speak(queued.first, queued.second)
    }

    override suspend fun isAvailable(): Boolean = !initFailed

    @Synchronized
    override fun speak(text: String, listener: SpeechListener) {
        this.listener = listener
        val engine = tts
        if (initFailed || engine == null) {
            listener.onError("Android TTS kullanılamıyor")
            return
        }
        if (!ready) {
            pending = text to listener
            return
        }
        engine.setSpeechRate(speechRate)
        engine.setPitch(pitch)
        val result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
        if (result == TextToSpeech.ERROR) listener.onError("Konuşma başlatılamadı")
    }

    override fun stop() {
        tts?.stop()
    }

    @Synchronized
    override fun release() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
