package com.jarvis.assistant.core

enum class HudPhase {
    IDLE, LISTENING, THINKING, EXECUTING, SPEAKING, HIGHLIGHTING, SUCCESS, ERROR
}

data class HudUiState(
    val phase: HudPhase = HudPhase.IDLE,
    val context: ContextInfo = ContextInfo.GENERAL,
    /** Gerçek amplitude (0..1). Dinlerken mikrofon RMS'inden gelir. */
    val amplitude: Float = 0f,
    /** Kullanıcının söylediği (kısmi veya final) metin. */
    val userText: String = "",
    val lastSpeech: String = "",
    /** TTS'in o ana kadar okuduğu karakter sayısı (gerçek progress callback'ten). */
    val spokenEnd: Int = 0,
    val error: String? = null,
    /** Hata olmayan bilgilendirme (ör. "Sizi duyamadım"). */
    val notice: String? = null,
    /** Mikrofon izni kalıcı reddedilmişse true: uygulama ayarlarına yönlendirme gösterilir. */
    val micBlocked: Boolean = false,
)
