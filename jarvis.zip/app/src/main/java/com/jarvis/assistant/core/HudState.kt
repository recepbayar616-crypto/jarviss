package com.jarvis.assistant.core

enum class HudPhase {
    IDLE, LISTENING, THINKING, EXECUTING, SPEAKING, HIGHLIGHTING, SUCCESS, ERROR
}

data class HudUiState(
    val phase: HudPhase = HudPhase.IDLE,
    val context: ContextInfo = ContextInfo.GENERAL,
    /** Gerçek playback amplitude (0..1). Sağlayıcı vermiyorsa 0 kalır. */
    val amplitude: Float = 0f,
    val lastSpeech: String = "",
    /** TTS'in o ana kadar okuduğu karakter sayısı (gerçek progress callback'ten). */
    val spokenEnd: Int = 0,
    val error: String? = null,
)
