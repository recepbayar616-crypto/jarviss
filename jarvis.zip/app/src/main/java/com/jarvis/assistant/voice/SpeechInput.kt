package com.jarvis.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

interface SpeechInputListener {
    fun onReady() {}
    fun onPartial(text: String) {}

    /** Mikrofon RMS'inden türetilmiş gerçek seviye, 0..1. */
    fun onLevel(level: Float) {}
    fun onEndOfSpeech() {}
    fun onFinal(text: String)
    fun onError(message: String, isNoSpeech: Boolean)
}

/**
 * Android SpeechRecognizer sarmalayıcısı. Tüm çağrılar ana thread'den yapılmalıdır.
 * Her dinleme için yeni recognizer oluşturulur ve bitince yok edilir (RECOGNIZER_BUSY önlemi).
 */
class SpeechInput(private val context: Context) {

    private var recognizer: SpeechRecognizer? = null

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun start(languageTag: String, listener: SpeechInputListener) {
        destroy()
        val r = try {
            SpeechRecognizer.createSpeechRecognizer(context)
        } catch (e: Exception) {
            listener.onError("Konuşma tanıma başlatılamadı.", false)
            return
        }
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                listener.onReady()
            }

            override fun onBeginningOfSpeech() {}

            override fun onRmsChanged(rmsdB: Float) {
                listener.onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                listener.onEndOfSpeech()
            }

            override fun onError(error: Int) {
                destroy()
                listener.onError(describe(error), error == SpeechRecognizer.ERROR_NO_MATCH ||
                    error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
            }

            override fun onResults(results: Bundle?) {
                val text = firstResult(results)
                destroy()
                if (text.isNullOrBlank()) {
                    listener.onError("Sizi duyamadım. Tekrar dokunup konuşun.", true)
                } else {
                    listener.onFinal(text)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                firstResult(partialResults)?.let { listener.onPartial(it) }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            if (Build.VERSION.SDK_INT >= 33) {
                // En iyi çaba: bazı cihazlarda ikinci bir dili de tanımaya izin verir.
                val other = if (languageTag.startsWith("tr")) "en-US" else "tr-TR"
                putStringArrayListExtra(RecognizerIntent.EXTRA_ADDITIONAL_LANGUAGES, arrayListOf(other))
            }
        }
        try {
            r.startListening(intent)
        } catch (e: Exception) {
            destroy()
            listener.onError("Konuşma tanıma başlatılamadı.", false)
        }
    }

    /** Konuşmayı bitirip sonucu işlemeye başlat. */
    fun stopListening() {
        recognizer?.stopListening()
    }

    /** Sonuç beklemeden iptal. */
    fun cancel() {
        destroy()
    }

    fun destroy() {
        val r = recognizer ?: return
        recognizer = null
        try {
            r.cancel()
            r.destroy()
        } catch (e: Exception) {
            // yok sayılır
        }
    }

    private fun firstResult(bundle: Bundle?): String? =
        bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()

    private fun describe(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Mikrofona erişilemedi (ses hatası)."
        SpeechRecognizer.ERROR_CLIENT -> "Konuşma tanıma istemci hatası. Tekrar deneyin."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mikrofon izni eksik."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            "Konuşma tanıma için internet bağlantısı gerekiyor."
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
            "Sizi duyamadım. Tekrar dokunup konuşun."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
            "Konuşma tanıma meşgul. Birkaç saniye sonra tekrar deneyin."
        SpeechRecognizer.ERROR_SERVER -> "Konuşma tanıma sunucusu hata verdi."
        10 -> "Çok fazla konuşma tanıma isteği. Biraz bekleyin."
        11 -> "Konuşma tanıma servisi bağlantısı koptu."
        12, 13 -> "Seçili dil bu cihazda desteklenmiyor veya yüklü değil."
        else -> "Bilinmeyen konuşma tanıma hatası ($error)."
    }
}
