package com.jarvis.assistant.core

import androidx.compose.ui.graphics.Color

object JarvisColors {
    val Background = Color(0xFF020609)
    val Cyan = Color(0xFF00D9FF)
    val DarkCyan = Color(0xFF006B8F)
    val LightCyan = Color(0xFFB8F2FF)
    val Error = Color(0xFFFF3B30)
}

data class ContextTheme(
    val primary: Color,
    val secondary: Color,
    val glow: Color,
    val line: Color,
    val panelAccent: Color,
    val header: Color,
)

/**
 * Tüm context renklerinin tek kaynağı. UI içinde if/else ile renk seçilmez.
 * Yeni uygulama: ContextColorRegistry.register("anahtar", theme(...)).
 */
object ContextColorRegistry {

    fun theme(primary: Color, secondary: Color = JarvisColors.DarkCyan): ContextTheme =
        ContextTheme(
            primary = primary,
            secondary = secondary,
            glow = primary.copy(alpha = 0.55f),
            line = primary,
            panelAccent = primary,
            header = primary,
        )

    private val cyanTheme = theme(JarvisColors.Cyan)

    private val themes = mutableMapOf(
        ContextKeys.GENERAL to cyanTheme,
        ContextKeys.YOUTUBE to theme(Color(0xFFFF0000)),
        ContextKeys.SPOTIFY to theme(Color(0xFF1DB954)),
        ContextKeys.WHATSAPP to theme(Color(0xFF25D366)),
        ContextKeys.GMAIL to theme(Color(0xFFEA4335)),
        ContextKeys.INSTAGRAM to theme(Color(0xFFE1306C), Color(0xFFFCAF45)),
        ContextKeys.GOOGLE to theme(Color(0xFF4285F4), Color(0xFFEA4335)),
        ContextKeys.CHROME to theme(Color(0xFF4285F4), Color(0xFF34A853)),
        ContextKeys.MAPS to theme(Color(0xFF34A853), Color(0xFF4285F4)),
        ContextKeys.CALENDAR to theme(Color(0xFF4285F4)),
        ContextKeys.ANDROID to theme(Color(0xFF3DDC84)),
        ContextKeys.WEATHER to theme(Color(0xFF4FC3F7)),
        ContextKeys.SYSTEM to cyanTheme,
        ContextKeys.NETWORK to theme(Color(0xFF2196F3)),
        ContextKeys.BATTERY to theme(Color(0xFF00E676)),
        ContextKeys.MEMORY to cyanTheme,
        ContextKeys.CAMERA to cyanTheme,
        ContextKeys.SCREEN to cyanTheme,
        ContextKeys.NOTIFICATIONS to cyanTheme,
    )

    fun register(key: String, theme: ContextTheme) {
        themes[key] = theme
    }

    /** Bilinmeyen anahtarda JARVIS cyan'a düşer. */
    fun resolve(key: String): ContextTheme = themes[key] ?: cyanTheme

    /** Pil durumuna göre yeşil / sarı / kırmızı. */
    fun batteryTheme(levelPercent: Int): ContextTheme = theme(
        when {
            levelPercent <= 15 -> Color(0xFFFF3B30)
            levelPercent <= 40 -> Color(0xFFFFC107)
            else -> Color(0xFF00E676)
        }
    )
}
