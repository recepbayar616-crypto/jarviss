package com.jarvis.assistant.voice

/** HUD'a gerçek playback ilerlemesini taşıyan dinleyici. Tahmini gecikme (delay) kullanılmaz. */
interface SpeechListener {
    fun onStart() {}

    /** Konuşulan metindeki karakter aralığı (sağlayıcı destekliyorsa). */
    fun onWordRange(start: Int, end: Int) {}

    /** Gerçek playback amplitude 0..1 (sağlayıcı destekliyorsa). */
    fun onAmplitude(level: Float) {}

    fun onDone() {}
    fun onError(message: String) {}
}

interface VoiceProvider {
    val id: String
    suspend fun isAvailable(): Boolean
    fun speak(text: String, listener: SpeechListener, languageTag: String = "tr-TR")
    fun stop()
    fun release()
}
