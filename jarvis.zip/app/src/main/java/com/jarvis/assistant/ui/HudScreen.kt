package com.jarvis.assistant.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.assistant.core.ContextColorRegistry
import com.jarvis.assistant.core.HudPhase
import com.jarvis.assistant.core.HudUiState
import com.jarvis.assistant.core.JarvisColors

@Composable
fun HudScreen(
    state: HudUiState,
    onGreet: () -> Unit,
    onSystemStatus: () -> Unit,
) {
    val theme = ContextColorRegistry.resolve(state.context.key)
    val primary by animateColorAsState(theme.primary, tween(300), label = "primary")
    val header by animateColorAsState(theme.header, tween(300), label = "header")
    val glow by animateColorAsState(theme.glow, tween(300), label = "glow")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisColors.Background)
            .padding(20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = state.context.title,
                color = header,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
            )
            Text(
                text = "  /  ● ${state.context.status}",
                color = JarvisColors.LightCyan,
                fontSize = 12.sp,
                letterSpacing = 1.sp,
            )
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center,
        ) {
            EnergyCore(phase = state.phase, color = primary, glow = glow)
        }

        val text = state.lastSpeech
        val end = state.spokenEnd.coerceIn(0, text.length)
        val annotated = buildAnnotatedString {
            withStyle(SpanStyle(color = primary)) { append(text.substring(0, end)) }
            withStyle(SpanStyle(color = Color.White.copy(alpha = 0.6f))) { append(text.substring(end)) }
        }
        Text(text = annotated, fontSize = 18.sp, modifier = Modifier.padding(bottom = 8.dp))

        state.error?.let {
            Text(text = it, color = JarvisColors.Error, fontSize = 13.sp)
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            val colors = ButtonDefaults.buttonColors(
                containerColor = primary.copy(alpha = 0.18f),
                contentColor = primary,
            )
            Button(onClick = onGreet, colors = colors) { Text("Merhaba") }
            Button(onClick = onSystemStatus, colors = colors) { Text("Sistem durumu") }
        }
    }
}

@Composable
private fun EnergyCore(phase: HudPhase, color: Color, glow: Color) {
    val infinite = rememberInfiniteTransition(label = "core")
    val angle by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)),
        label = "angle",
    )
    val pulse by infinite.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            tween(1100, easing = FastOutSlowInEasing),
            RepeatMode.Reverse,
        ),
        label = "pulse",
    )
    val intensity by animateFloatAsState(
        targetValue = if (phase == HudPhase.IDLE) 0.45f else 1f,
        animationSpec = tween(300),
        label = "intensity",
    )

    Canvas(modifier = Modifier.size(260.dp)) {
        val c = center
        val r = size.minDimension / 2f

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(glow.copy(alpha = 0.55f * intensity), Color.Transparent),
                center = c,
                radius = r,
            ),
            radius = r,
            center = c,
        )
        drawCircle(
            color = color.copy(alpha = 0.9f * intensity),
            radius = r * 0.28f * pulse,
            center = c,
        )
        drawCircle(
            color = color.copy(alpha = 0.5f),
            radius = r * 0.55f,
            center = c,
            style = Stroke(width = 2.dp.toPx()),
        )
        rotate(angle, c) {
            drawArc(
                color = color,
                startAngle = 0f,
                sweepAngle = 100f,
                useCenter = false,
                topLeft = Offset(c.x - r * 0.8f, c.y - r * 0.8f),
                size = Size(r * 1.6f, r * 1.6f),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
            )
            drawArc(
                color = color,
                startAngle = 180f,
                sweepAngle = 60f,
                useCenter = false,
                topLeft = Offset(c.x - r * 0.8f, c.y - r * 0.8f),
                size = Size(r * 1.6f, r * 1.6f),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
            )
        }
        rotate(-angle * 1.5f, c) {
            drawArc(
                color = color.copy(alpha = 0.6f),
                startAngle = 40f,
                sweepAngle = 140f,
                useCenter = false,
                topLeft = Offset(c.x - r * 0.68f, c.y - r * 0.68f),
                size = Size(r * 1.36f, r * 1.36f),
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round),
            )
        }
    }
}
