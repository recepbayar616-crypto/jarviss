package com.jarvis.assistant.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.assistant.core.ContextColorRegistry
import com.jarvis.assistant.core.HudPhase
import com.jarvis.assistant.core.HudUiState
import com.jarvis.assistant.core.JarvisColors

@Composable
fun HudScreen(
    state: HudUiState,
    language: String,
    onMic: () -> Unit,
    onGreet: () -> Unit,
    onSystemStatus: () -> Unit,
    onLanguage: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAppSettings: () -> Unit,
) {
    val theme = ContextColorRegistry.resolve(state.context.key)
    val isError = state.phase == HudPhase.ERROR
    val primary by animateColorAsState(
        if (isError) JarvisColors.Error else theme.primary, tween(300), label = "primary",
    )
    val header by animateColorAsState(
        if (isError) JarvisColors.Error else theme.header, tween(300), label = "header",
    )
    val glow by animateColorAsState(
        if (isError) JarvisColors.Error.copy(alpha = 0.55f) else theme.glow, tween(300), label = "glow",
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisColors.Background)
            .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = state.context.title,
                color = header,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
            )
            Text(
                text = "  /  ● ${state.context.status}",
                color = JarvisColors.LightCyan,
                fontSize = 12.sp,
                letterSpacing = 1.sp,
            )
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onOpenSettings) {
                Text("AYARLAR", color = primary, fontSize = 12.sp, letterSpacing = 1.sp)
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center,
        ) {
            EnergyCore(phase = state.phase, color = primary, glow = glow, amplitude = state.amplitude)
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 170.dp)
                .verticalScroll(rememberScrollState()),
        ) {
            if (state.userText.isNotBlank()) {
                Text(
                    text = "SİZ: ${state.userText}",
                    color = JarvisColors.LightCyan,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
            }
            val text = state.lastSpeech
            val end = state.spokenEnd.coerceIn(0, text.length)
            val annotated = buildAnnotatedString {
                withStyle(SpanStyle(color = primary)) { append(text.substring(0, end)) }
                withStyle(SpanStyle(color = Color.White.copy(alpha = 0.6f))) { append(text.substring(end)) }
            }
            Text(text = annotated, fontSize = 18.sp)
            state.notice?.let {
                Text(text = it, color = JarvisColors.LightCyan, fontSize = 14.sp)
            }
            state.error?.let {
                Text(text = it, color = JarvisColors.Error, fontSize = 14.sp)
            }
        }

        if (state.micBlocked) {
            TextButton(onClick = onOpenAppSettings) {
                Text("UYGULAMA AYARLARINI AÇ (mikrofon izni)", color = JarvisColors.Error, fontSize = 12.sp)
            }
        }

        val micLabel = when (state.phase) {
            HudPhase.LISTENING -> "● DİNLİYORUM…  (bitirmek için dokun)"
            HudPhase.THINKING, HudPhase.EXECUTING -> "DÜŞÜNÜYORUM…  (iptal için dokun)"
            HudPhase.SPEAKING -> "KONUŞUYOR…  (sözünü kesmek için dokun)"
            else -> "🎤  KONUŞ"
        }
        Button(
            onClick = onMic,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp)
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = primary.copy(alpha = if (state.phase == HudPhase.LISTENING) 0.45f else 0.22f),
                contentColor = primary,
            ),
        ) {
            Text(micLabel, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val small = PaddingValues(horizontal = 4.dp)
            @Composable
            fun colorsFor(selected: Boolean) = ButtonDefaults.buttonColors(
                containerColor = primary.copy(alpha = if (selected) 0.45f else 0.12f),
                contentColor = primary,
            )
            Button(
                onClick = onGreet,
                modifier = Modifier.weight(1.3f),
                colors = colorsFor(false),
                contentPadding = small,
            ) { Text("Merhaba", fontSize = 12.sp) }
            Button(
                onClick = onSystemStatus,
                modifier = Modifier.weight(1.6f),
                colors = colorsFor(false),
                contentPadding = small,
            ) { Text("Sistem durumu", fontSize = 12.sp) }
            Button(
                onClick = { onLanguage("tr") },
                modifier = Modifier.weight(0.8f),
                colors = colorsFor(language == "tr"),
                contentPadding = small,
            ) { Text("TR", fontSize = 12.sp) }
            Button(
                onClick = { onLanguage("en") },
                modifier = Modifier.weight(0.8f),
                colors = colorsFor(language == "en"),
                contentPadding = small,
            ) { Text("EN", fontSize = 12.sp) }
        }
    }
}

@Composable
private fun EnergyCore(phase: HudPhase, color: Color, glow: Color, amplitude: Float) {
    val infinite = rememberInfiniteTransition(label = "core")
    val angle by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)),
        label = "angle",
    )
    val pulse by infinite.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            tween(1100, easing = FastOutSlowInEasing),
            RepeatMode.Reverse,
        ),
        label = "pulse",
    )
    val intensity by animateFloatAsState(
        targetValue = if (phase == HudPhase.IDLE) 0.45f else 1f,
        animationSpec = tween(300),
        label = "intensity",
    )
    val amp by animateFloatAsState(
        targetValue = amplitude,
        animationSpec = tween(100),
        label = "amp",
    )

    Canvas(modifier = Modifier.size(260.dp)) {
        val c = center
        val r = size.minDimension / 2f

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(glow.copy(alpha = (0.45f + 0.4f * amp) * intensity), Color.Transparent),
                center = c,
                radius = r,
            ),
            radius = r,
            center = c,
        )
        drawCircle(
            color = color.copy(alpha = 0.9f * intensity),
            radius = r * 0.28f * pulse * (1f + amp * 0.5f),
            center = c,
        )
        drawCircle(
            color = color.copy(alpha = 0.5f),
            radius = r * 0.55f,
            center = c,
            style = Stroke(width = 2.dp.toPx()),
        )
        if (amp > 0.02f) {
            drawCircle(
                color = color.copy(alpha = 0.7f * amp),
                radius = r * (0.6f + amp * 0.3f),
                center = c,
                style = Stroke(width = 3.dp.toPx()),
            )
        }
        rotate(angle, c) {
            drawArc(
                color = color,
                startAngle = 0f,
                sweepAngle = 100f,
                useCenter = false,
                topLeft = Offset(c.x - r * 0.8f, c.y - r * 0.8f),
                size = Size(r * 1.6f, r * 1.6f),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
            )
            drawArc(
                color = color,
                startAngle = 180f,
                sweepAngle = 60f,
                useCenter = false,
                topLeft = Offset(c.x - r * 0.8f, c.y - r * 0.8f),
                size = Size(r * 1.6f, r * 1.6f),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
            )
        }
        rotate(-angle * 1.5f, c) {
            drawArc(
                color = color.copy(alpha = 0.6f),
                startAngle = 40f,
                sweepAngle = 140f,
                useCenter = false,
                topLeft = Offset(c.x - r * 0.68f, c.y - r * 0.68f),
                size = Size(r * 1.36f, r * 1.36f),
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round),
            )
        }
    }
}
