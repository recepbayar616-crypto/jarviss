package com.jarvis.assistant.tool

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import com.jarvis.assistant.core.ContextInfo
import com.jarvis.assistant.core.ContextKeys

/** Gerçek cihaz verisi: pil, ağ, depolama, model, Android sürümü. */
class SystemStatusTool(private val context: Context) : Tool {

    override val name = NAME
    override val description = "Cihazın pil, ağ, depolama ve sistem bilgisini döndürür."
    override val inputSchema = """{"type":"object","properties":{}}"""
    override val contextInfo = ContextInfo(ContextKeys.SYSTEM, "SYSTEM STATUS", "SYSTEM MONITORING")

    override suspend fun execute(args: Map<String, String>): ToolResult {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val network = when {
            caps == null -> "bağlantı yok"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobil veri"
            else -> "diğer ağ"
        }

        val stat = StatFs(Environment.getDataDirectory().path)
        val freeGb = stat.availableBytes / 1_000_000_000.0
        val totalGb = stat.totalBytes / 1_000_000_000.0

        val chargeText = if (charging) "şarj oluyor" else "şarj olmuyor"
        val summary = "Pil yüzde $level, $chargeText. Ağ: $network. " +
            "Depolamada %.0f gigabayt boş. Cihaz ${Build.MODEL}, Android ${Build.VERSION.RELEASE}."
                .format(freeGb)

        return ToolResult.Success(
            summary = summary,
            data = mapOf(
                "batteryLevel" to level.toString(),
                "charging" to charging.toString(),
                "network" to network,
                "storageFreeGb" to "%.1f".format(freeGb),
                "storageTotalGb" to "%.1f".format(totalGb),
                "model" to Build.MODEL,
                "androidVersion" to Build.VERSION.RELEASE,
            ),
        )
    }

    companion object {
        const val NAME = "system_status"
    }
}
