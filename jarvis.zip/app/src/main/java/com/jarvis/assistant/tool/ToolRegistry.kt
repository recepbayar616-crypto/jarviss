package com.jarvis.assistant.tool

import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import kotlin.coroutines.cancellation.CancellationException

class ToolRegistry(private val context: Context) {

    private val tools = linkedMapOf<String, Tool>()

    fun register(tool: Tool) {
        tools[tool.name] = tool
    }

    fun get(name: String): Tool? = tools[name]

    fun all(): List<Tool> = tools.values.toList()

    suspend fun execute(name: String, args: Map<String, String> = emptyMap()): ToolResult {
        val tool = tools[name] ?: return ToolResult.Failure("Bilinmeyen araç: $name")

        val missing = tool.requiredPermissions.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            return ToolResult.Failure("Gerekli izin verilmemiş: ${missing.joinToString()}")
        }

        return try {
            tool.execute(args)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ToolResult.Failure("İşlem başarısız oldu: ${e.message ?: e.javaClass.simpleName}")
        }
    }
}
