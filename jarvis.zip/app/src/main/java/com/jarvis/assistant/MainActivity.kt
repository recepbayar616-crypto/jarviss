package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.assistant.ui.HudScreen
import com.jarvis.assistant.ui.JarvisViewModel
import com.jarvis.assistant.ui.SettingsScreen

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: JarvisViewModel = viewModel()
            val state by vm.state.collectAsStateWithLifecycle()
            val settings by vm.settingsState.collectAsStateWithLifecycle()
            var showSettings by rememberSaveable { mutableStateOf(false) }

            val permissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestPermission()
            ) { granted ->
                if (granted) {
                    vm.onMicClicked()
                } else {
                    val canAskAgain = ActivityCompat.shouldShowRequestPermissionRationale(
                        this@MainActivity, Manifest.permission.RECORD_AUDIO
                    )
                    vm.onMicPermissionDenied(permanentlyBlocked = !canAskAgain)
                }
            }

            BackHandler(enabled = showSettings) { showSettings = false }

            if (showSettings) {
                SettingsScreen(
                    s = settings,
                    onBack = { showSettings = false },
                    onSaveKey = vm::saveApiKey,
                    onClearKey = vm::clearApiKey,
                    onSaveModel = vm::saveModel,
                    onTest = vm::testGemini,
                )
            } else {
                HudScreen(
                    state = state,
                    language = settings.language,
                    onMic = {
                        val granted = ContextCompat.checkSelfPermission(
                            this@MainActivity, Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        if (granted) vm.onMicClicked()
                        else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    onGreet = vm::greet,
                    onSystemStatus = vm::showSystemStatus,
                    onLanguage = vm::setLanguage,
                    onOpenSettings = { showSettings = true },
                    onOpenAppSettings = ::openAppSettings,
                )
            }
        }
    }

    private fun openAppSettings() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
        )
    }
}
