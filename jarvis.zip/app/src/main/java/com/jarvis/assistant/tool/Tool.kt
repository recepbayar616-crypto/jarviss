package com.jarvis.assistant.tool

import com.jarvis.assistant.core.ContextInfo

sealed interface ToolResult {
    data class Success(
        val summary: String,
        val data: Map<String, String> = emptyMap(),
    ) : ToolResult

    data class Failure(val message: String) : ToolResult
}

interface Tool {
    val name: String
    val description: String

    /** Gemini function-calling için JSON schema (string). */
    val inputSchema: String

    /** Gereken Android runtime izinleri (Manifest.permission.*). */
    val requiredPermissions: List<String> get() = emptyList()

    /** HUD header + renk için context. */
    val contextInfo: ContextInfo

    suspend fun execute(args: Map<String, String>): ToolResult
}
